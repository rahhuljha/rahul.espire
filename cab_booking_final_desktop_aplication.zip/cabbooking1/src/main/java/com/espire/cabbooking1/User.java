package com.espire.cabbooking1;

public class User {
	private String username;
	private String password;
	private String role;
	private boolean checked;
	
	
	public User() {}
	public User(String username, String password, String role, boolean checked) {
		this.username = username;
		this.password = password;
		this.role = role;
		this.checked = checked;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public boolean isChecked() {
		return checked;
	}
	public void setChecked(boolean checked) {
		this.checked = checked;
	}
	@Override
	public String toString() {
		return "User [username=" + username + ", password=" + password + ", role=" + role + ", checked=" + checked
				+ "]";
	}
	
}
