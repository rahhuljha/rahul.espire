package com.espire.cabbooking1.daoimpl;

import java.sql.SQLException;

import com.espire.cabbooking1.dao.AdminDao;
import com.espire.cabbooking1.serviceimpl.AdminServiceImpl;

public class AdminDaoImpl implements AdminDao{
	AdminServiceImpl adminSerImpl=new AdminServiceImpl();
	@Override
	public void viewAllCabs() throws SQLException{
		adminSerImpl.getAllCabs();
		return;
	}

	@Override
	public void viewAllPassengers() throws SQLException{
		adminSerImpl.getAllPassengers();
		return;
	}

	@Override
	public void viewAllBookings() throws SQLException{
		adminSerImpl.getAllBookings();
		return;
	}

}
