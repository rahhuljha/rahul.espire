package com.espire.cabbooking1.dao;

import java.sql.SQLException;

public interface PassengerDAO {
	void bookTheRide() throws SQLException;
	void cancelTheBooking() throws SQLException;
}
