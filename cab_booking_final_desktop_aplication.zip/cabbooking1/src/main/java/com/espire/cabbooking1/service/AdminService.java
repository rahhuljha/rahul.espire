package com.espire.cabbooking1.service;

import java.sql.SQLException;

import com.espire.cabbooking1.Booking;
import com.espire.cabbooking1.Cab;
import com.espire.cabbooking1.Passenger;

public interface AdminService {
	public Cab getAllCabs()throws SQLException;
	public Passenger getAllPassengers()throws SQLException;
	public Booking getAllBookings()throws SQLException;
}
